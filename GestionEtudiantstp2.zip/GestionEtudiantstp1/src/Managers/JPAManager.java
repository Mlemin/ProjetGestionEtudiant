/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Managers;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author macbook
 */
// JPA Manager est singleton
public class JPAManager {
    public EntityManagerFactory factory;
    public EntityManager em;
    private static final JPAManager instance = new JPAManager();
    // Creer le constructeur privee
    private JPAManager(){
    // effectuer l'initialisation une seule fois
    factory = Persistence.createEntityManagerFactory("GestionEtudiantstp1PU");
    em = factory.createEntityManager();
    }
    
    // Methode publique qui retourne cette instance de JPAManager
    public static JPAManager getInstance(){
        return instance;
    }
    
    
}
